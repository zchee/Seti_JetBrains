def foo():
    print 'bar'


def long_function_name(
        var_one, var_two, var_three,
        var_four):
    print(var_one)