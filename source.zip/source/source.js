/**
 * Created by Chee on 12/17/14.
 */
var globalVar
/**
 * Constructor for <code>AjaxRequest</code> class
 * @param url th eurl for the request<p/>
 */
function AjaxRequrst(url) {
  var urls = [ "www.cnn.com", 5, globalVar];
  this.request = new XMLHttpRequest();
  url = url.replace(/^\s*(.*)/, "$1"); // slip leading whitespace
  /* check the url to be in urls */
  var a = "\u1111\z\n\u11";
  this.foo = new function() {};
  foo();
  #
}
