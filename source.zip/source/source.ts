foo(
    "demo",
    {
        title: "Demo",
        width: 100
    },
    function () {
        alert("test");
    }
);