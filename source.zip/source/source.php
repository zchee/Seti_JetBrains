<?php
function foo()
{
    if ($x > 5) {
        echo "bar";
    }
    return
        "string";
}
