CREATE TABLE SampleTable (
  id          INT PRIMARY KEY,
  description VARCHAR(62)
);

SELECT
  id,
  description
FROM product
WHERE supplier LIKE '2008%' AND id > 3;

SELECT
  col_x * 100 AS `iddd`,
  id / 100,
  88 + 2000,
  id + 7         i
FROM guest.indexed
  JOIN `test_table` ON test_table.id = iddd
WHERE id <> 1 OR id > 10 OR id = 1
GROUP BY 1
HAVING iddd > 10
ORDER BY 2
LIMIT 100;

CREATE VIEW test AS
  SELECT *
  FROM dual;

INSERT INTO users (id, name) VALUES (1, '1'), (2, '2');

INSERT INTO users SELECT *
                  FROM users;

SELECT *
FROM (SELECT
        decode(message_type, '1', 'type_1', '2', 'type_2') AS mess_type,
        messages_data.*,
        test_table,
        mess_type                                          AS m
      FROM messages_data
);

DELIMITER //

CREATE FUNCTION SimpleCompare(
  n INT,
  m VARCHAR(200)
)
  RETURNS VARCHAR(20)

  BEGIN DECLARE s VARCHAR(20);
    IF n > m
    THEN SET s = '>';
    ELSEIF n = m
      THEN SET s = '=';
    ELSE SET s = '<'; END IF;
    SET s = CONCAT(n, ' ', s, ' ', m);
    RETURN s;
  END //

DELIMITER ;
